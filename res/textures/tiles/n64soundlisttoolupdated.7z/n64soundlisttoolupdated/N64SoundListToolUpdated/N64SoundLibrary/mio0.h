#pragma once

class MIO0
{
public:
	unsigned long mio0_decode ( unsigned char *src, unsigned char * destination );
	int mio0_get_size( unsigned char * src);
};
