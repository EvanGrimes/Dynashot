// Spinout
#pragma once

#include "SoundToolExports.h"

class YAY0
{
public:
	int decodeAll(unsigned char * src, unsigned char* result, int& fileSizeCompressed);
};
